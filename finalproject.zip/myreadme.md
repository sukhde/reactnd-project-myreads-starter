# MyReads Project

Each book has a control that  you can  select the shelf for that book. When you select a different shelf, the book moves there. 
   The different categories such as currently reading,
want to read and read.

 ## Images

 ![picture]()

 ## Author
 
Sukhdeep Sidhu